#ifndef FILESYSTEMDB_H
#define FILESYSTEMDB_H

#include "../../data/filesystem/file.h"
#include "idatabase.h"

namespace cerberus
{
    namespace db
    {
        class FilesystemDB : public IDatabase
        {
            struct Table
            {
                HASH32 tableID;
                DBTableProto proto;
                LSIZE header;  // position in file where the table header begins
                LSIZE buffer;  // position in file where the table data begins

                Table()
                    : tableID(0),
                      proto(),
                      header(0),
                      buffer(0) {};

                Table(HASH32 id, const DBTableProto& proto, LSIZE h, LSIZE b)
                    : tableID(id),
                      proto(proto),
                      header(h),
                      buffer(b) {};
            };

            struct Buf_Size
            {
                ByteBuffer buf;
                LSIZE size;
            };

            File m_file;

            std::vector<Table> m_tables;

            StringOpRes _readStr();

            DBMOD _getMod(const ByteBuffer& buf);

            OpRes _parseTableHeader(Table& tab);

            OpRes _load();

            OpRes _buildHeader(const DBTableProto& prototype, Table& tab);

            OpResData<Buf_Size> _parseFieldRaw(DBDataType type, DBMOD mod);

            OpResData<DBCell> _parseField(DBDataType type, DBMOD mod);

            OpResData<DBTableBlock> _getTable(Table& tab);

            OpRes _insertBlock(Table* tab, const DBTableBlock& block);

           public:
            FilesystemDB();

            virtual OpRes init(const std::string& parameters);

            virtual void deinit();

            virtual bool ready() const;

            virtual OpRes command(const string& query);

            virtual OpResData<DBTableBlock> queryBlock(const string& query);  // not impl

            virtual OpResData<DBTableProto> queryPrototype(const string& tableName);

            virtual OpRes createTable(const DBTableProto& prototype);

            virtual OpRes insertBlock(const DBTableBlock& block);

            virtual OpRes dropTable(const std::string& table);  // not impl

            inline virtual OpResData<DBTableBlock> querytable(const std::string& tableName);

            virtual ~FilesystemDB();
        };
    }  // namespace db
}  // namespace cerberus

#endif  // FILESYSTEMDB_H
