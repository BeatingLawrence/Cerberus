#ifndef CERBERUS_TIME_SYSTIMER_H
#define CERBERUS_TIME_SYSTIMER_H

#ifdef LINUX_SYSTEM

#include <signal.h>
#include <time.h>

#include <atomic>

#include "../types.h"
#include "./timeframe.h"

namespace cerberus
{
    namespace time
    {
        class SysTimer
        {
           private:
            timerCallback m_callback;
            void* m_ctx;

            static void defaultTimeoutCallback(void* ctx);

            static void mainCallback(sigval val);

            std::atomic_bool m_running;

            timer_t m_timerId;

            bool m_failed, m_periodic;

            TimeFrame m_time;

           public:
            SysTimer();

            SysTimer(const TimeFrame& time, bool periodic = false);

            SysTimer(const SysTimer& other) = delete;

            ~SysTimer();

            void setTime(const TimeFrame& time);

            void start();

            void stop();

            void reset();

            bool isRunning();

            bool isFailed();

            // Sets a callback to be executed when the timer expires
            void provideTimeoutCallback(timerCallback callback, void* ctx = nullptr);
        };
    }  // namespace time
}  // namespace cerberus

#endif
#endif  // CERBERUS_TIME_SYSTIMER_H
